package br.elibrary.graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ELibraryGraphQlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ELibraryGraphQlApplication.class, args);
	}

}
